using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SpaceShooter
{
    public class Enemy : MonoBehaviour
    {
        public GameObject bulletPrefab;
        public GameObject Target;
        public float spawnRateMin = 0.5f;
        public float spawnRateMax = 3f;

        public float WeithMinSize = -13f;
        public float WeithMaxSize = 13f;

        private float spawnRate;
        private float timeAfterSpawn;

        public float moveSpeed = 5;

        bool isTrue = true;

        private void Start()
        {
            timeAfterSpawn = 0f;
            spawnRate = Random.Range(spawnRateMin, spawnRateMax);
            
        }

        private void Update()
        {
            timeAfterSpawn += Time.deltaTime;
            if (timeAfterSpawn >= spawnRate)
            {
                timeAfterSpawn = 0f;

                GameObject bullet
                    = Instantiate(bulletPrefab, transform.position, transform.rotation);
                spawnRate = Random.Range(spawnRateMin, spawnRateMax);
            }


            

             if (transform.position.x < WeithMinSize)
            {
                transform.position = new Vector3(WeithMinSize, transform.position.y);
            }
            else if (transform.position.x > WeithMaxSize)
            {
                transform.position = new Vector3(WeithMaxSize, transform.position.y);
            }

            if (isTrue)
            {
                transform.Translate(new Vector3(1, 0) * Time.deltaTime * moveSpeed);
                if (transform.position.x >= (WeithMaxSize - 1)) isTrue = false;
            }
            else if (isTrue == false)
            {
                transform.Translate(new Vector3(-1, 0) * Time.deltaTime * moveSpeed);
                if (transform.position.x <= (WeithMinSize + 1)) isTrue = true;
            }

        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            
            if (other.CompareTag("PlayerBullet"))
            {
                Destroy(Target);
            }
        }
    }
}