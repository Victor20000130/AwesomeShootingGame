using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class EnemySpawner : MonoBehaviour
{

    public GameObject enemyPrefab;
    public float spawnRateMin = 0.5f;
    public float spawnRateMax = 3f;
    //private Sprite[] spriteArr = Resources.LoadAll<Sprite> ("Enemy");
    

    private float spawnRate;
    private float timeAfterSpawn;

    public float WeithMinSize = -13f;
    public float WeithMaxSize = 13f;
    public float HeightMinSize = 5f;
    public float HeightMaxSize = 10f;

    private void Start()
    {
        timeAfterSpawn = 0f;
        spawnRate = Random.Range(spawnRateMin, spawnRateMax);
        transform.position = new Vector3(WeithMinSize, transform.position.y);
    }
    private void Update()
    {
        timeAfterSpawn += Time.deltaTime;

        if (timeAfterSpawn >= spawnRate)
        {
            timeAfterSpawn = 0f;
            float x = Random.Range(WeithMinSize, WeithMaxSize);
            float y = Random.Range(HeightMinSize, HeightMaxSize);
            enemyPrefab.transform.position.Set(x, y, 0);
            enemyPrefab.transform.localScale = new Vector3(2f, 2f, 2f);
            int Arrnum = Random.Range(1, 21);
            //enemyPrefab.GetComponent<SpriteRenderer>().sprite  = spriteArr[Arrnum];
            GameObject enemy = Instantiate(enemyPrefab, enemyPrefab.transform.position, enemyPrefab.transform.rotation);
        }
    }
}
