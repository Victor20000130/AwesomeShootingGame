using SpaceShooter;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SpaceShooter
{
    public class Bullet : MonoBehaviour
    {
        public float speed = 8f;
        private Rigidbody2D bulletRigidbody;

        private void Start()
        {
            bulletRigidbody = GetComponent<Rigidbody2D>();
            bulletRigidbody.velocity = transform.forward * speed;

            Destroy(gameObject, 5f);
        }


    }
}
